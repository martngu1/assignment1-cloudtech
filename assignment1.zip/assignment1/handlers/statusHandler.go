package handlers

import (
	"net/http"
)

func StatusHandler(w http.ResponseWriter, r *http.Request) {

}
