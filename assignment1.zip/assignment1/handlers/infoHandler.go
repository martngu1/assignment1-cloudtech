package handlers

import (
	"net/http"
)

func InfoHandler(w http.ResponseWriter, r *http.Request) {

	switch r.Method {
	case http.MethodGet:

	}

}
