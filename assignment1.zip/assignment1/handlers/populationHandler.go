package handlers

import (
	"net/http"
)

func PopulationHandler(w http.ResponseWriter, r *http.Request) {

}
