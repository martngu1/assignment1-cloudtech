package services

import (
	"assignment1/models"
)

func GetCountryInfo(code string) (*models.CountryInfo, error) {

}
